from sr import *
from define import *
from vision import *

"""Checks intersection between PosA1 PosA2, PosB1 and PosB2"""
def CheckIntersection(PosA1,PosA2,PosB1,PosB2):
    #Min and Max X values
    MinAX = min(PosA1[0],PosA2[0])
    MaxAX = max(PosA1[0],PosA2[0])
    MinBX = min(PosB1[0],PosB2[0])
    MaxBX = max(PosB1[0],PosB2[0])
    
    #Find Equation for line A
    YA=PosA2[1]-PosA1[1]
    XA=PosA2[0]-PosA1[0]
    if XA <> 0:
        MA=YA/XA
        CA = PosA1[1]-MA*PosA1[0]
        
    #Find Equation for line B
    YB=PosB2[1]-PosB1[1]
    XB=PosB2[0]-PosB1[0]
    if XB <> 0:
        MB=YB/XB
        CB = PosB1[1]-MB*PosB1[0]
        
    #if One of them is Vertical
    if (XA == 0):
        X = PosA1[0]
    elif (XB == 0):
        X = PosB1[0]
    else:
        #Parallel Lines
        if MA == MB:
            #If the constants are the same, they are the same line.
            if CB == CA:
                #Final Check, if the ranges intersect, it intersects.
                if (MaxAX >= MinBX) or (MaxBX >= MinAX):
                    return True
                else:
                    return False                
        else:
            X = (CB-CA)/(MA-MB)
    
    #The Equations intersect, Huzzah. But do they intersect in the bounds?
    if MinAX <= X <= MaxAX:
        if MinBX <= X <= MaxBX:
            return True
    #Failing this, Return False.
    return False            
        
def MoveByWaypoints():
    pass#IMPLEMENT THIS

def MoveLocalRoute(TargetPos,WayPoints=[]):
    if len(WayPoints) == 0:
        WayPoints = [(0,0),TargetPos]
    global AvoidDistance,AvoidBy
    
    MarkerInfo = See()["All"]
    for i in range(1,len(WayPoints)):
        for m in MarkerInfo:
            #If the target position isn't too close to be impossible to 
            MPos = (m.centre.world[0],m.centre.world[1])
            if math.hypot(TargetPos[0]-MPos[0],TargetPos[1]-MPos[1]) > 0.5:
                #+,+
                OutsidePos = (MPos[0]+AvoidDistance,MPos[1]+AvoidDistance)
                if CheckIntersection(MPos,OutsidePos,WayPoints[i-1],WayPoints[i]):
                    WayPoints.insert(i-1,(MPos[0]+AvoidBy,MPos[1]+AvoidBy))
                    return MoveLocalRoute(TargetPos,WayPoints)
                
                #+,-
                OutsidePos = (MPos[0]+AvoidDistance,MPos[1]-AvoidDistance)
                if CheckIntersection(MPos,OutsidePos,WayPoints[i-1],WayPoints[i]):
                    WayPoints.insert(i-1,(MPos[0]+AvoidBy,MPos[1]-AvoidBy))
                    return MoveLocalRoute(TargetPos,WayPoints)
                    
                #-,+
                OutsidePos = (MPos[0]-AvoidDistance,MPos[1]+AvoidDistance)
                if CheckIntersection(MPos,OutsidePos,WayPoints[i-1],WayPoints[i]):
                    WayPoints.insert(i-1,(MPos[0]-AvoidBy,MPos[1]+AvoidBy))
                    return MoveLocalRoute(TargetPos,WayPoints)
                    
                #-,-
                OutsidePos = (MPos[0]-AvoidDistance,MPos[1]-AvoidDistance)
                if CheckIntersection(MPos,OutsidePos,WayPoints[i-1],WayPoints[i]):
                    WayPoints.insert(i-1,(MPos[0]-AvoidBy,MPos[1]-AvoidBy))
                    return MoveLocalRoute(TargetPos,WayPoints)
                
def NavigateWayPoints(WayPoints):
    for P in WayPoints:
        pass#Continue from here