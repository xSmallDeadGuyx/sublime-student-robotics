from define import *
"""Drive straight for x Seconds"""
def DriveforSecs(Time):
    global Dp, DriveSpeed,HasntMovedSinceLastSee
    HasntMovedSinceLastSee = False
    #allow for driving negative distances
    DrivePower=math.copysign(DriveSpeed,Time)
    
    #time_to_drive=distance
    stime=time.time()
    t=stime
    Time = math.fabs(Time)
    #while the time isn't over
    while t < stime+Time:
        g=GetGyro()
        t=time.time()
        #Set the proportional to gyro*constant
        P = g*Dp
        I=0
        D=0
        PID=P+I+D
        #print "t=",t,"g=",g,"P =",P,"l=",DrivePower+PID,"r=",-(DrivePower-PID)        
        #Set the motors to these values

        LeftMotor.target = DrivePower+PID
        RightMotor.target = -(DrivePower-PID)
    LeftMotor.target = 0
    RightMotor.target = 0
    
"""Drive straight for x Metres"""
def Drive(Distance):
    global DistanceDivisor, DistancePower
    """
    (^ = 'to the power of')
    y=distance
    x=time
        y=mx^c
    Therefore
        x=(y/m)^(1/c)
    """
    time=abs(Distance/DistanceDivisor)**(1/DistancePower)
    time=math.copysign(time,Distance)
    print "Driving",Distance,"metres, which is for",math.fabs(time),"seconds."
    DriveforSecs(time)
    return time