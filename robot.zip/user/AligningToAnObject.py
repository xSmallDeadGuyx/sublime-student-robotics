from define import *
from drive import *
from turning import *
from vision import *

"""Look for tokens by turning Seek_Angle (30) degrees at a time
returns a list of all markers found""" 
def SeekForMarkers(MarkerList,give_Up=360,direction=1):
    global Seek_Angle
    found=[]
    for i in range(0,give_Up/Seek_Angle):
        time.sleep(0.5)
        markers=See()["All"]
        for m in markers:
            if m.info.code in MarkerList:
                #Ignore any markers on top
                if abs(m.orientation.rot_x)<30:
                    found.append(m)
        if len(found) > 0:
            return found
        TurnBy(Seek_Angle*direction, tol=5)
    return found

"""Aligning to a Cube / Plinth 
    -target_markers is the number of the marker you want to align to
    -ang_offset is the angle you want it to align to the object at
    -final_offset is the distance from the object you'd hope to be at the end
    -drivestraighttoit should be True if you think you're lined up with it
    -ForceStraightToit should be true if you don't care what angle you approac it at

"""
def AlignToMarker(target_markers,ang_offset=0,final_offset=-0.1,SeekDirection=1,ForceStraightToit=False,drivestraighttoit=False):
    global align_dist, object_width, AttemptTolerance

    markers=SeekForMarkers(target_markers,direction=SeekDirection)
    #If it couldn't find it, return False because it's gone and lost itself now :(
    if len(markers) == 0:
        return False
    else:
        marker = markers[0]
    #if the marker is over 3m away, drive towards it and try again.
    if marker.dist > 3:
        print "Marker is too far away, moving towards it"
        TurnBy(marker.rot_y)
        Drive(1)
        #Call it recursively
        return AlignToMarker(target_markers,ang_offset,final_offset,SeekDirection,ForceStraightToit)
    
    temp_align_dist = marker.dist if marker.dist < align_dist else align_dist

    #All co-ordinates are handled in (X,Y), X being 'away' and Y being 'right'
    
    #Clockwise angle from forwards
    face_ang=marker.orientation.rot_y
    print 'face_ang =',face_ang
        
    #Z is parallel to camera, X is to the left.
    """marker_pos is the position of the marker relative to the robot"""
    marker_pos = (marker.centre.world.z,marker.centre.world.x)
    print 'marker_pos =',marker_pos
    
    """centre_pos is the position of the centre relative to the robot"""
    centre_pos = (marker_pos[0]+(object_width/2)*math.cos(math.radians(face_ang)),\
    marker_pos[1]+(object_width/2)*math.sin(math.radians(face_ang)))
    print 'centre_pos =',centre_pos

    """align_ang is the angle which the robot needs to align to to be flush to
    do whatever it needs to do"""
    #Choose which corner to approach
    if face_ang > 0:
        align_ang = face_ang - ang_offset#-45
    else:
        align_ang = face_ang + ang_offset#+45
    print 'align_ang =',align_ang
    
    """pos_from_centre is the target alignment position from the centre relative to
    the robot"""
    pos_from_centre = (temp_align_dist*math.cos(math.radians(align_ang)),\
    temp_align_dist*math.sin(math.radians(align_ang)))
    print 'pos_from_centre =', pos_from_centre
    
    """align_pos is the target alignment position relative to
    the robot"""
    align_pos = (centre_pos[0]-pos_from_centre[0],\
    centre_pos[1]-pos_from_centre[1])
    print 'align_pos =', align_pos
    
    """angle_to_turn should be the angle which the robot needs to turn to go
    to the alignment position"""
    angle_to_turn = math.degrees(math.atan2(align_pos[1],\
    align_pos[0]))
    print 'angle_to_turn =', angle_to_turn
    
    """dist_to_drive is the distance which the robot should drive once it's 
    at the right angle"""
    dist_to_drive = math.hypot(align_pos[0],align_pos[1])
    print 'dist_to_drive =', dist_to_drive
    
    """angle_to_turn_back should be the angle it turns to face the cube/pillar now that its
    at the right pos"""
    angle_to_turn_back = align_ang-angle_to_turn
    print 'angle_to_turn_back',angle_to_turn_back
    
    #if it isn't driving straight to it
    if (not drivestraighttoit) and (not ForceStraightToit):
        TurnBy(angle_to_turn)
        time.sleep(0.3)
        Drive(dist_to_drive)
        time.sleep(0.3)
        TurnBy(angle_to_turn_back)
        time.sleep(0.3)
        #see if it's there. If it is, pick it up, Call it recursively
        
        #If it loses it, try to look more in the direction of the angle it was meant to turn back by
        Direction = math.copysign(1,angle_to_turn_back)
        
        return AlignToMarker(target_markers,ang_offset,final_offset,Direction,True)
    else:
        centre_offset_angle=math.degrees(math.atan2(centre_pos[1],centre_pos[0]))
        print 'centre_offset_angle =',centre_offset_angle
        #if it's close enough to straight, or the flag to 'just go' is on:
        if (abs(centre_pos[1]) < AttemptTolerance) or ForceStraightToit:
            
            TurnBy(centre_offset_angle)
            
            centre_distance=math.hypot(centre_pos[0],centre_pos[1])
            print 'centre_distance =',centre_distance
            
            #Drive to it. Assume you managed it :)                
            Drive(centre_distance-final_offset)
            time.sleep(1)#Sleep to allow for the robot to settle down
            return True
        else:#if it's not reasonably ahead, try to align again.
            return AlignToMarker(target_markers,ang_offset,final_offset)