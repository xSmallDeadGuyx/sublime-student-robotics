"""This code allows for the robot to find out where it is based on 2 markers in the arena"""
"""!!!Not very reliable from far distances!!"""
from define import *
from vision import *
# set a dictionary of the Positions of every marker
mpositions={
#South Wall
7:  (8,1),
8:  (8,2),
9:  (8,3),
10: (8,4),
11: (8,5),
12: (8,6),
13: (8,7),
#West Wall
6:  (7,0),
5:  (6,0),
4:  (5,0),
3:  (4,0),
2:  (3,0),
1:  (2,0),
0:  (1,0),
    #North Wall
27: (0,1),
26: (0,2),
25: (0,3),
24: (0,4),
23: (0,5),
22: (0,6),
21: (0,7),
    #East Wall
14: (7,8),
15: (6,8),
16: (5,8),
17: (4,8),
18: (3,8),
19: (2,8),
20: (1,8),
    #Pedestals
#NW
32: (2,2),
#N
33: (2,4),
#NE
34: (2,6),
#W
35: (4,2),
#C
36: (4,4),
#E
37: (4,6),
#SW
38: (6,2),
#S
39: (6,4),
#SE
40: (6,6)
}
    
#Function to find the distance between two markers
def find_l_between_markers(MarkerA,MarkerB):
    #difference in X and Y
    dx = mpositions[MarkerA.info.code][0]-mpositions[MarkerB.info.code][0]
    dy = mpositions[MarkerA.info.code][1]-mpositions[MarkerB.info.code][1]
    #return the length between them
    return math.hypot(dx, dy)

#Rotate a position around the origin
def MatrixRotate(Pos,Angle):
    #Calculate the rotational matrix
    #| Cos x, -Sin x |
    #| Sin x,  Cos x |
    sinA = math.sin(Angle)
    cosA = math.cos(Angle)
    Rotated = (Pos[0]*cosA - Pos[1]*sinA,\
               Pos[0]*sinA + Pos[1]*cosA)
    return Rotated
    
# Function which finds two possible locations based on 2 markers
# returns an array of Tuples
def findPossibleLocations(MrkA,MrkB):
    MrkAPos = mpositions[MrkA.info.code]
    MrkBPos = mpositions[MrkB.info.code]
    #Distances of the markers
    DistMrkA = MrkA.centre.polar.length
    DistMrkB = MrkB.centre.polar.length
    #print "the database says Marker",MrkA.info.code,"is at: ",MrkAPos
    #print "it is",DistMrkA,"Metres away"
    #print "the database says Marker",MrkB.info.code,"is at: ",MrkBPos
    #print "it is",DistMrkB,"Metres away"
    #Transform the MrkBPos so it is local to MrkA
    #   do this by subtracting A from B
    """
        Calculations:
    Let the centers be: (a,b), (c,d)
    Let the radii be: r, s
      e = c - a                          [difference in x coordinates]
      f = d - b                          [difference in y coordinates]
      p = sqrt(e^2 + f^2)                [distance between centers]
      k = (p^2 + r^2 - s^2)/(2p)         [distance from center 1 to line
                                          joining points of intersection]
      x = a + ek/p + (f/p)sqrt(r^2 - k^2)
      y = b + fk/p - (e/p)sqrt(r^2 - k^2)
    OR
      x = a + ek/p - (f/p)sqrt(r^2 - k^2)
      y = b + fk/p + (e/p)sqrt(r^2 - k^2)
    """
    Difference = (MrkBPos[0]-MrkAPos[0],MrkBPos[1]-MrkAPos[1])
    
    #Find the Distance between the two
    DiffDist = math.hypot(MrkBPos[0],MrkBPos[1])#MatrixRotate(MrkBPos,-Angle)
    
    #Distance from Centre A to the line joining the points of intersection
    DistToLine=(DiffDist**2+DistMrkA**2-DistMrkB**2)/(2*DiffDist)
    
    MidVar = (DistMrkA**2-DistToLine**2)**-2
    
    OffsetX=(Difference[1]/DiffDist)*MidVar
    OffsetY=(Difference[0]/DiffDist)*MidVar
    
    PotentialPosA=(\
    MrkAPos[0]+(MrkBPos[0]*DistToLine)/DiffDist+OffsetX,\
    MrkAPos[1]+(MrkBPos[1]*DistToLine)/DiffDist-OffsetY)
    
    PotentialPosB=(\
    MrkAPos[0]+(MrkBPos[0]*DistToLine)/DiffDist-OffsetX,\
    MrkAPos[1]+(MrkBPos[1]*DistToLine)/DiffDist+OffsetY)
    
    """
    #Find the angle of MrkBPos
    Angle = math.atan2(MrkBPos[1],MrkBPos[0])
    
    #Find the Distance between the two
    MrkBDistanceFromMrkA = math.hypot(MrkBPos[0],MrkBPos[1])#MatrixRotate(MrkBPos,-Angle)
    
    #Use the Bilaterate equations to find the positions of the robot
    #X = (Ra^2 - Rb^2 - 1)/2XB
    #Y = (+/-)sqrt(Ra^2 - X^2)
    PotentialX = (DistMrkA**2-DistMrkB**2-1)/(2*MrkBDistanceFromMrkA)
    PotentialY = math.sqrt(abs(DistMrkA**2-PotentialX**2))
    
    #PosB is only PosA with an inverted Y.
    PotentialPosA = (PotentialX, PotentialY)
    PotentialPosB = (PotentialX, -PotentialY)
    
    #Rotate the vectors back to get them correct
    PotentialPosA = MatrixRotate(PotentialPosA,Angle)
    PotentialPosB = MatrixRotate(PotentialPosB,Angle)
    
    #move the vectors so they are relative to the origin.
    PotentialPosA = (PotentialPosA[0]+MrkAPos[0],PotentialPosA[1]+MrkAPos[1])
    PotentialPosB = (PotentialPosB[0]+MrkAPos[0],PotentialPosB[1]+MrkAPos[1])
    #returns an array of 2 tuples
    """
    return [PotentialPosA,PotentialPosB]
#Finds if the position is on the correct side of the markers
#Uses the Polar co-ordinates from the camera
def IsCorrectSide(Pos,MrkA,MrkB):
    MrkAPos = mpositions[MrkA.info.code]
    MrkBPos = mpositions[MrkB.info.code]
          
    #Find the local vector of the markers based on Pos
    LPosA = (MrkAPos[0]-Pos[0],MrkAPos[1]-Pos[1])
    LPosB = (MrkBPos[0]-Pos[0],MrkBPos[1]-Pos[1])
    
    #Find the angle of Local vector A
    Angle = math.atan2(LPosA[1],LPosA[0])
    #Rotate the Local vector B by the angle.
    LPosB = MatrixRotate(LPosB,-Angle)

    if MrkA.rot_y < MrkB.rot_y:
        leftMarker = MrkA.info.code
    else:
        leftMarker = MrkB.info.code
    
    #if the Y is greater than 0, it's to the left of MrkA, 
    #note it's impossible to have an angle of 0 because they'll be overlapping
    if LPosB[1] < 0:
        arenaLeftMarker = MrkA.info.code
    else:
        arenaLeftMarker = MrkB.info.code
    
    #print "The camera says that the left marker is", leftMarker
    #print "Marker", arenaLeftMarker, "is actually to the left"
    
    # return True if the camera and the arena agree
    return leftMarker == arenaLeftMarker

def FindRobotPos(Immobile_markers):
    #print "there are ",len(Immobile_markers),"markers seen"    
    
    #//FINDING THE POSITION OF MARKERS
    PossiblePlaces = []
    NewP = []

    
    for i in xrange(0,len(Immobile_markers)):
        m1 = Immobile_markers[i]
        """#////////FINDING THE POSITION OF THE ROBOT FROM SINGLE MARKERS
        DOESN'T WORK BECAUSE THE COMPASS IS UNRELIABLE. It's staying commented here in case of a miracle, though.
        #Uses the angle from the ST Board
        A = math.radians(getAngle()-m1.rot_y)#Rot_y is negative when clockwise, unlike convention
        L = m1.dist
        MP = mpositions[m1.info.code]
        print "Pos =",MP
        P = (MP[0]+(L*math.sin(A)),MP[1]+(L*math.cos(A)))       
        PossiblePlaces.append((P,L))
        print "rotation",getAngle()
        print "Angle",A,"from Marker",m1.info.code,"is",P"""
        #////////FINDING THE POSITION OF THE ROBOT FROM 2 MARKERS
        #Only runs when there's 2 or more markers
        #Try every combination of markers and get their positions
        for j in xrange(i+1,len(Immobile_markers)):
            m2 = Immobile_markers[j]
            #print "trying",m1.info.code,"against",m2.info.code
            if mpositions[m1.info.code] <> mpositions[m2.info.code]:
                NewP = findPossibleLocations(m1,m2)
                for P in NewP:
                    #Find which marker should be on the left, check if it is.
                    #(if it isn't, remove it)
                    if not IsCorrectSide(P,m1,m2):
                        #print "Rejecting", P, "because it is not on the correct side"
                        continue# Goes to the next Pos
            
                    #we're keeping this one if it succeeds both tests, but
                    #first we'll store the furthest distance of marker
                    MaxDistance = max(m1.dist, m2.dist)
            
                    #Then add this to the array
                    PossiblePlaces.append((P,MaxDistance))
                
    """Now that we have a list of positions that the robot is in, we need to get
    a single estimate from these values
    Things to remember when doing this:
        - The further away markers are, the less likely they will be correct.
        (I'm assuming this is a square relationship though it probably isn't)
    """
    #EDIT, Changed to a Cubed relationship in the hope it increases accuracy of results
    if len(PossiblePlaces) > 0:
        #Total Square Distance
        TotSqDist = 0
        #Total of all the positions
        PosTotal = (0,0)
        #Finds the weighted average of the positions
        for T in PossiblePlaces:
            print T[0]
            SqDist = T[1]**-2
            #Add the position weighted by the inverse Squared distance
            #ie if something is 2x further, it is 4x less effective on the mean pos
            PosTotal = (PosTotal[0]+T[0][0]*SqDist,\
                        PosTotal[1]+T[0][1]*SqDist)
            #Add up the squared distance
            TotSqDist += SqDist
            
        #Finally, calculate the weighted average position from the sums
        PosTotal = (PosTotal[0]/TotSqDist,PosTotal[1]/TotSqDist)

        """Move the position so it's relative to the Starting Zone"""
        """#Step 1: subtract (4,4) so the centre is around the origin
        PosTotal = (PosTotal[0]-4,PosTotal[1]-4)
        #Step 2: rotate by the correct amount
        PosTotal = MatrixRotate(PosTotal,math.radians(-90*Zone))
        #Step 3: add (4,4) again so the position makes sense
        PosTotal = (PosTotal[0]+4,PosTotal[1]+4)"""
        #X IS SOUTH, Y IS EAST (The robot always starts in the NW corner)
        print "GLOBAL POS ESTIMATE: x:"+str(PosTotal[0])+" y:"+str(PosTotal[1])
        return PosTotal
    else:
        return False