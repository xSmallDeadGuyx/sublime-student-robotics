from define import *
import time
def getP(heading,Ang):
    P = Pmul*(Ang - heading)
    P = AngleLocalise(P)
    return P
"""Turn to a certain angle"""
def TurnTo(Ang, tolerance=4, timeout=4):
    global Tp, Ti, Td, Pmul,minMotorPower,StopSpeedTolerance,HasntMovedSinceLastSee
    HasntMovedSinceLastSee = False
    try:
        prevTime = 0
        curTime = time.clock()
        prevP = 0
        P = getP(GetCompass(),Ang)
        I = 0
        D = 0

        startTime = time.time()
    
        while ((abs(P) > tolerance) or (abs(GetGyro()) > StopSpeedTolerance)) and time.time() - startTime < timeout:
            prevTime = curTime
            prevP = P
            #Wait until the clock is different
            while curTime == prevTime:
                curTime = time.time()
            dTime = curTime - prevTime
            A = GetCompass()
            P = getP(A,Ang)
            I += P * dTime
            D = (P-prevP) / dTime
            targetSpeed = 0
            targetSpeed = (Tp*P+Ti*I+Td*D)
            targetSpeed += math.copysign(minMotorPower, targetSpeed)
            RightMotor.target = targetSpeed
            LeftMotor.target = targetSpeed
            #print "P=%6.3f I=%6.3f D=%6.3f A=%6.3f PID=%s" % ( P, I, D, A, targetSpeed)
            # print " %6.3f,%6.3f,%6.3f,%6.3f,%6.3f,%6.3f" % (P, I, A,Ang,GetGyro(), targetSpeed)
    finally:
        RightMotor.target = 0
        LeftMotor.target = 0

"""Turn by a certain angle"""
def TurnBy(Ang, tol=2):
    CurAng=GetCompass()
    TargetAng = AngleLocalise(CurAng+Ang)
    print "Turning By",Ang,"Degrees, from",CurAng,"to",TargetAng
    TurnTo(TargetAng, tolerance=tol)