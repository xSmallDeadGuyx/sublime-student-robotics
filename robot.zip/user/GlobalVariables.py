"""GLOBAL VARIABLES
   [F]ramebot or [P]acbot??"""
    
Bot = 'F'#[F]ramebot or [P]acbot functions?
#(Only handles raw functions, need to change the Global variables below too.)

#inverts the pump because framebot is wired to be On unless told not to.
PumpInvert=True#F, True, P False

#Turning (Compass PID)
Tp=0.8#Pacbot 0.6, Framebot 0.75
Ti=0.0
Td=0.0
Pmul=-1#pacbot: 1, Framebot -1nt "Driving forward 0.5m"

minMotorPower = 34#Pacbot 22 Framebot 22 

#Maximum acceptable Speed in degrees per second for the robot to be turning to finish at
#(ie if it's wobbling too much it'd be going at higher than 10 degrees per second)
StopSpeedTolerance = 10
    
#Driving (Gyro PID)
Dp=-2.7#pacbot 1, framebot -2.7
#To configure these values plot the distance against time graph of the robot and
#then add a 'Power' trendline for it
DistanceDivisor=0.77 #pacbot 0.59, framebot 0.77
DistancePower=1.08 #pacbot 1.29, framebot 1.08

DriveSpeed = 90#Speed at which the robot should drive

#Aligning Constants
align_dist=1#Distance to move to for alignment with the marker
ang_offset=0#pacbot 45 (due to the V mouth), framebot 0
object_width=0.30#width of the object to align to
Seek_Angle=25#Angle which the robot turns each time to look for cubes
AttemptTolerance=0.10#Tolerance in metres for an attempt to drive straight towards the object

#Avoiding Objects
AvoidDistance=0.5
AvoidBy=0.8
"""Pillars are:
    NW N NE
    W  C  E
    SW S SE
    
    32  33  34 
    35  36  37
    38  39  40
STARTING AT TOP LEFT CORNER!!!
"""
#STARTING AT NW CORNER!!
StringPillarOrder=\
['NW','N','W','C','NE','SW']
