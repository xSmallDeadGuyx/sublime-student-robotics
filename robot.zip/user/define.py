from sr import *
from GlobalVariables import *
import math
import time

R=Robot()
Zone=R.zone
#Motor Definition
RightMotor=R.motors[0]
LeftMotor=R.motors[1]
Pump=R.io[0].output[3]

"""Angle Localise, should be used to prevent getting
values above 180 or below -180"""
def AngleLocalise(Ang):
    while Ang > 180:
        Ang -= 360
    while Ang < -180:
        Ang += 360
    return Ang

#defining the mbed
import serial
mbed = serial.Serial('/dev/ttyACM0', 921600)

#Getting the Angle from the Compass
def GetCompass():
    mbed.write("c")
    s=mbed.readline()
    #Exception handling for the mbed outputting two strings in one go.
    try:
        n = float(s)
        if not math.isnan(n):
            return n
        else:
            print "!!!!!NaN Compass! Getting new one!!!!!"
            return GetCompass()
    except:
        print "!!!!!Float Concatenation error from MBed for Compass!!!!!"
        return GetCompass()
        
#Getting the Rotational Velocity from the Gyro
def GetGyro():
    mbed.write("g")
    s=mbed.readline()
    #Exception handling for the mbed outputting two strings in one go.
    try:
        n = float(s)
        if not math.isnan(n):
            return n
        else:
            print "!!!!!NaN Gyro! Getting new one!!!!!"
            return GetGyro()
    except:
        print "!!!!!Float Concatenation error from MBed for Gyro!!!!!"
        return GetGyro()
        
#Getting the Arm Position from the Rheostat
def GetArmPos():
    mbed.write("a")
    s=mbed.readline()
    #Exception handling for the mbed outputting two strings in one go.
    try:
        n = float(s)
        if not math.isnan(n):
            return n
        else:
            print "!!!!!NaN Arm Pos! Getting new one!!!!!"
            return GetArmPos()
    except:
        print "!!!!!Float Concatenation error from MBed for Arm Pos!!!!!"
        return GetArmPos()

#Managing inversion of pumps because framebot is wired inversely
if PumpInvert: 
    def PumpOn():
        Pump.d = 0
        
    def PumpOff():
        Pump.d = 1
else:
    def PumpOn():
        Pump.d = 1
        
    def PumpOff():
        Pump.d = 0
        
"""Arm movement Functions"""
if Bot == 'F': #FRAMEBOT Arm motions       
    #Set Arm Velocity (upwards)
    def SetArmVel(speed):
        R.servos[0][0] = 50.0 + speed
    
    #Set Arm Position to X 
    def MoveArmTo(target, speedMod=1, timeout=3):
        armValue = GetArmPos()
        startTime = time.time()
        print "Moving arm to", target, "at time", startTime
        while abs(armValue - target) > 500 and time.time() - startTime < timeout:
            SetArmVel((20 if (target - armValue > 0) else -10) * speedMod)
            print "\tArm value:", armValue, "- Arm speed:", R.servos[0][0]
            armValue = GetArmPos()
        SetArmVel(0)
    
    #Move arm to the 'Up' position
    def ArmUp(sMod=0.75):
        MoveArmTo(54000, speedMod=sMod, timeout=2)
    
    def GrabToken():
        print "Turning pump on"
        PumpOn()
        MoveArmTo(12500, timeout=1.5)
        SetArmVel(0)
        time.sleep(0.5)
        ArmUp()
    
    def DropToken():
        print "Turning pump off"
        PumpOff()
        print "Setting arm velocity to -40"
        SetArmVel(-40)
        time.sleep(0.1)
        print "Setting arm velocity to 0"
        SetArmVel(0)
        time.sleep(2)
        print "Arm up"
        ArmUp()
    
    def InitialiseArm():
        SetArmVel(0)
        time.sleep(0.5)
        SetArmVel(-3)
        time.sleep(0.3)
        SetArmVel(0)
        
else: #PACBOT Arm motions    
    def ArmUp():
        R.servos[0][0] = 50.0
        
    def ArmDown():
        R.servos[0][0] = 0.0
        
    def GrabToken():
        PumpOn()
        ArmDown()
        time.sleep(2)
        ArmUp()
        #Pacbot can't tell if it's picked up a cube sadly :(
    
    def DropToken():
        ArmUp()
        PumpOff()
        #*Engage Shake manouver*
        #(Will hopefully look funny)
        ArmDown()
        time.sleep(0.2)
        ArmUp()
        ArmDown()
        time.sleep(0.1)
        ArmUp()
    
    #Pacbot needs to do nothing when it initialises :)
    def InitialiseArm():
        pass 
    
HasntMovedSinceLastSee = False

