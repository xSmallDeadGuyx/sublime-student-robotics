from define import *
#Dictionary of all pillars so NW is always the Closest.
PillarDict=\
[{
    #Zone 0
    'NW':32,
    'N':33,
    'NE':34,
    'W':35,
    'C':36,
    'E':37,
    'SW':38,
    'S':39,
    'SE':40    
    },\
    {
    #Zone 1
    'NW':34,
    'N':37,
    'NE':40,
    'W':33,
    'C':36,
    'E':39,
    'SW':32,
    'S':35,
    'SE':38    
    },\
    {
    #Zone 2
    'NW':40,
    'N':39,
    'NE':38,
    'W':37,
    'C':36,
    'E':35,
    'SW':34,
    'S':33,
    'SE':32    
    },\
    {
    #Zone 3
    'NW':38,
    'N':35,
    'NE':32,
    'W':39,
    'C':36,
    'E':33,
    'SW':40,
    'S':37,
    'SE':34    
    }]
    
#Building the Priority List of pillars    
PillarOrder = []
for P in StringPillarOrder:
    PillarOrder.append(PillarDict[Zone][P])

"""Active Tokens are tokens which haven't been 'placed' by the robot yet"""
ActiveTokens = [\
41+Zone*6,\
42+Zone*6,\
43+Zone*6,\
44+Zone*6,\
45+Zone*6,\
46+Zone*6]

"""Active Tokens are tokens which have been 'placed' by the robot"""
UnactiveTokens=[]


#Removes the Pillar in the list
def NextPillar():
    P = PillarOrder.pop[0]
    print "Pillar",P,"Removed from priority"
    
#Removes a Token from the Active list and puts it into the Unactive list
def EliminateToken(ID):
    ActiveTokens.remove(ID)
    UnactiveTokens.append(ID)
    
"""Marker_Info Class, stores arrays of every sort of marker you would ever wish for
class Marker_Info(object):
    def __init__(self,All=[], Arena=[], Robots=[], Pedestals=[], OurActiveTokens=[],OurUnactiveTokens=[],EnemyTokens=[]):
        self.All=All
        self.Arena=Arena
        self.Robots=Robots
        self.Pedestals=Pedestals
        self.OurActiveTokens=OurActiveTokens
        self.OurUnactiveTokens=OurUnactiveTokens
        self.EnemyTokens=EnemyTokens"""

"""See, Returns all markers in a 'MarkerInfo' dictionary, sorted by distance"""
def See():
    #Marker_Info Dictionary, actually does what you meant it to do.
    MarkerInfo = {"All":[], "Arena":[], "Robots":[], "Pedestals":[], "OurActiveTokens":[], "OurUnactiveTokens":[], "EnemyTokens":[]}
    global LastMarkerInfo,HasntMovedSinceLastSee
    #if HasntMovedSinceLastSee:
    #    return LastMarkerInfo
    markers = R.see()
    #Sort the markers by distance, 
    #(I love that python makes it 1 line to do this)
    markers.sort(key=lambda x: x.dist)
    
    #Categorise the markers into different arrays
    MarkerInfo["All"] = markers
    for m in markers:
        #print "marker %f is %.3f meters away and %.3f degrees x rotation" %(m.info.code, m.dist, m.centre.polar.rot_y)
        #Arena
        if m.info.marker_type == MARKER_ARENA:
            MarkerInfo["Arena"].append(m)
        #Robots
        if m.info.marker_type == MARKER_ROBOT:
            MarkerInfo["Robots"].append(m)
        #Pedestals
        if m.info.marker_type == MARKER_PEDESTAL:
            MarkerInfo["Pedestals"].append(m)
        #Tokens
        if m.info.marker_type == MARKER_TOKEN:
            c=m.info.code
            
            #Our Active Tokens are tokens that haven't been eliminated yet
            if c in ActiveTokens:
                MarkerInfo["OurActiveTokens"].append(m)
                
            #Our Unactive Tokens are tokens that have been eliminated
            elif c in UnactiveTokens:
                MarkerInfo["OurUnactiveTokens"].append(m)
                
            #Enemy Tokens are tokens that are the enemy's
            else:
                MarkerInfo["EnemyTokens"].append(m)
    LastMarkerInfo = MarkerInfo
    HasntMovedSinceLastSee = True
    return MarkerInfo
    
