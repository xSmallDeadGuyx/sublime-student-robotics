from define import *
from turning import *
from drive import *
from vision import *
from AligningToAnObject import *
from VisionPositioning import *
StartTime=time.time()

print 'place initial cube (41) in fist area (w). this is the first move'
AlignToMarker(ActiveTokens[0],45)
GrabToken()
ArmUp()
print 'drive to first area'
Drive(4)
AlignToMarker(PillarOrder[0])
DropToken()

print 'place second cube (42) in closest area (NW)'
print 'drive back'
Drive(-3.5)
print 'turn to face tokens'
TurnBy(-90)
print 'align to marker'
AlignToMarker(ActiveTokens[0],45)
print 'grab the token'
ArmDown()
GrabToken()
ArmUp()
print 'drive away from other cubes'
Drive(-1)
print 'turn to second area'
TurnBy(90)
print 'drive into second area'
Drive(1)
print 'drop cube'
AlignToMarker(PillarOrder[1])
DropToken()

print 'place third cube (43) in third area (N)'
print 'drive away from placed cube'
Drive (-1)
print 'turn towords cubes'
TurnBy(-90)
print 'align to token'
AlignToMarker(ActiveTokens[0],45)
print 'grab cube'
ArmDown()
GrabToken()
ArmUp()
print 'drive away from other cubes'
Drive(-1)
print 'turn to face third area'
TurnBy(45)
print 'driving to position in third area'
Drive(4)
AlignToMarker(PillarOrder[2])
DropToken()