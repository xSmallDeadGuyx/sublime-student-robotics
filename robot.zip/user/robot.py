from define import *
from turning import *
from drive import *
from vision import *
from AligningToAnObject import *
from VisionPositioning import *
StartTime=time.time()

#Start Facing Towards Cubes

#Initialise the Arm Motor Controller for Framebot because the motor controller is weird.
#(this function is blank if pacbot, no need to remove it for Pacbot's code)
print "Initialising arm"
InitialiseArm()

#Prevent Runaway-robot-syndrome if the USB lost connection (stop all motor stuff)
RightMotor.target = 0
LeftMotor.target = 0
print "Turning pump off"
PumpOff()
print "Arm to top"
ArmUp()
time.sleep(1)

initialHeading = GetCompass()
headingToBase = initialHeading + 180
if headingToBase > 180:
	headingToBase -= 360
if headingToBase < -180:
	headingToBase += 360

print "Driving forward 0.5m"
Drive(0.5)
time.sleep(1)
print "Grabbing cube"
GrabToken()
time.sleep(1)
print "Driving forward 3m"
Drive(3)
time.sleep(0.5)
print "Turning -90"
TurnBy(-90, tol=5)
time.sleep(0.5)
print "Aligning to plinth"
AlignToMarker(xrange(32, 41))
time.sleep(0.5)
print "Dropping cube"
DropToken()
time.sleep(0.5)
print "Arm up"
ArmUp()
time.sleep(0.5)
print "Driving back 1m"
Drive(-1)
time.sleep(1)
print "Turning -90"
TurnBy(-90, tol=5)
time.sleep(1)
print "Driving 2m"
Drive(2)
time.sleep(0.5)
print "Aligning to one of our tokens"
AlignToMarker(ActiveTokens)
time.sleep(0.5)
print "Grabbing cube"
GrabToken()
time.sleep(0.5)
print "Driving back 0.5m"
Drive(-0.5)
time.sleep(0.5)
print "Turning by 135"
TurnBy(135, tol=5)
time.sleep(0.5)
print "Aligning to plinth"
AlignToMarker(xrange(32, 41), SeekDirection=-1)
time.sleep(0.5)
print "Dropping cube"
DropToken()
time.sleep(0.5)
print "Arm up"
ArmUp()
time.sleep(0.5)
print "Driving back 0.5m"
Drive(-0.5)
time.sleep(0.5)
print "Turning to base:", headingToBase
TurnTo(headingToBase, tolerance=5)
time.sleep(0.5)
print "Finding token"
AlignToMarker(ActiveTokens)
time.sleep(0.5)
print "Grabbing cube"
GrabToken()
time.sleep(1)
print "Driving back 0.5m"
Drive(-0.5)
time.sleep(1)
print "Turning to initialHeading", initialHeading
TurnTo(initialHeading, tolerance=5)
time.sleep(0.5)
print "Turning -45"
TurnBy(-45, tol=5)
time.sleep(0.5)
print "Finding plinth"
AlignToMarker(xrange(32, 41))
time.sleep(0.5)
print "Dropping cube"
DropToken()
time.sleep(0.5)
print "Arm up"
ArmUp()
time.sleep(0.5)
print "Driving back 0.5m"
Drive(-0.5)
time.sleep(0.5)
MoveArmTo(1000, timeout=2)

print "Competition code over"

# time.sleep(1)
# print "Driving forward 0.5m"
# Drive(0.5)
# time.sleep(1)
# print "Grabbing cube"
# GrabToken()
# time.sleep(1)
# print "Driving forward 0.8m"
# Drive(0.8)
# time.sleep(1)
# print "Dropping cube"
# DropToken()
# time.sleep(0.5)
# print "Arm back up"
# ArmUp()
# time.sleep(0.5)
# print "Driving backwards 1m"
# Drive(-1)
# print "Eliminating token", ActiveTokens[0]
# EliminateToken(ActiveTokens[0])
# print "New ActiveTokens:", ActiveTokens
# time.sleep(0.5)
# print "Turning -90"
# TurnBy(-90)
# time.sleep(0.5)
# print "Aligning to marker in ActiveTokens"
# AlignToMarker(ActiveTokens,SeekDirection=-1)#[ActiveTokens[0]])
# print "Grabbing cube"
# GrabToken()
# time.sleep(0.5)
# print "Turning 135"
# TurnBy(135)
# time.sleep(0.5)
# print "Driving forward 2.5m"
# Drive(2.5)
# time.sleep(0.5)
# print "Dropping cube"
# DropToken()
# print "Arm up"
# ArmUp()

# CUBE LIFT TEST
# GrabToken()
# time.sleep(1)
# ArmUp()
# time.sleep(1)
# DropToken()
# time.sleep(1)
# ArmUp()

"""
print "Aligning to marker"
AlignToMarker([38])#PillarOrder[0])
>>>>>>> 85640763949f02d70d1713adc428f135501d4e82

# while True:
#     AlignToMarker(ActiveTokens,SeekDirection=1)
#     GrabToken()
#     PumpOn()
#     Drive(-2)

while True:
    Markers=See()
    ImmobileMarkers=Markers["Arena"]+Markers["Pedestals"]
    print FindRobotPos(ImmobileMarkers)
"""